package CoreJava.CustomExceptions;

public class StudentRegistrationException extends Exception{


	public StudentRegistrationException(String message) {
		super(message);
	}
	
}
